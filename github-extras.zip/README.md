# Hermetic Trading System

This repository contains a Streamlit app for astrological and market analysis.