# Streamlit app
import streamlit as st
st.title('Hermetic Trading System')